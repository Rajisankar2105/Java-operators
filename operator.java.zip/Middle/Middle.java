 class Middle
{
	public static void main(String[] args) {
	     int num=543;
	     int middleDigit=(num/10)%10;
	     System.out.println("middle digit is:"+ middleDigit);
	}
}
	
