
 class Firstnlast
{
	public static void main(String[] args) {
	   int num=753;
	    int firstDigit=num/100;
	    int lastdigit=num%10;
	    int sum=firstDigit+lastdigit;
		System.out.println("sum of first and last digit:"
		+ sum);
	}
}
