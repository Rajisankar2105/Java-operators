 class Remainder
{
	public static void main(String[] args) {
	    int a=12;
	    int b=10;
		System.out.println(a%b);
	}
}
