import java.util.Scanner;
 class Absolute
{
	public static void main(String[] args) {
	    Scanner sc=new Scanner(System.in);
	int a =-143;
	int absValue=Math.abs(a);
	    System.out.println(absValue);
	}
}
